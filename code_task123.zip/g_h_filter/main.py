# %% [markdown]
# based the G-H Filter lecture, implement a filter to provide better estimation of following weight data
# Measurements = [73.4472422467988, 75.72608281704865,
# 75.87836357445472, 76.85574739762383, 76.29859314942073,
# 77.02466906493402, 76.45403447379701, 80.265950373462,
# 77.68679531108153, 78.43667833894177, 83.61568112163384,
# 84.49480154690445, 79.53123363124529, 84.28680302126494,
# 80.52805584038289, 85.68198420802062, 83.3779484821631,
# 85.70449238628278, 84.96601224144315, 85.69686880021742]
#
# G-H filter使得估计值能够随着预测公式和实际测量值进行调整。主要是通过更新dx和最近一次预测值x_est来实现的

# %%
import matplotlib.pyplot as plt
import numpy as np

from g_h_filter import g_h_filter


# %%
def main():
    data = [73.4472422467988, 75.72608281704865,
            75.87836357445472, 76.85574739762383, 76.29859314942073,
            77.02466906493402, 76.45403447379701, 80.265950373462,
            77.68679531108153, 78.43667833894177, 83.61568112163384,
            84.49480154690445, 79.53123363124529, 84.28680302126494,
            80.52805584038289, 85.68198420802062, 83.3779484821631,
            85.70449238628278, 84.96601224144315, 85.69686880021742]
    x0 = 60
    dx = 0.5
    g = 0.2
    h = 0.02
    dt = 1
    results, predictions = g_h_filter(data, x0, dx, g, h, dt)

    days = np.linspace(1, 20, 20)  # Days from 1 to 20 for the data
    actual_weight = 0.5 * np.linspace(0, 20, 21) + x0  # Including day 0 for actual weight model

    plt.figure(figsize=(15, 5))
    plt.plot(np.linspace(0, 20, 21), actual_weight, color='green', label='Actual weight', marker='*')
    plt.scatter(days, data, label='Measured weight', color='black', marker='o')
    plt.plot(days, predictions, label='Prediction', color='red', linestyle='--', marker='x')
    plt.plot(days, results, label='Filtered', color='blue', marker='+')
    plt.xticks(np.arange(0, 21), ['Day {}'.format(i) for i in range(0, 21)])
    plt.xlabel('Days')
    plt.ylabel('Weight')
    plt.title('Task 3: G-H Filter with a larger noise')
    plt.legend()
    plt.grid(True)
    plt.show()


# %%
if __name__ == "__main__":
    main()


