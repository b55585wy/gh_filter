import numpy as np


def plot(data,fun):
    nums = np.linspace(0, len(data), len(data))  # Days from 1 to 20 for the data
    actual_weight = 0.5 * np.linspace(0, 20, 20) + x0  # Including day 0 for actual weight model

    plt.figure(figsize=(15, 5))
    plt.plot(np.linspace(0, 20, 21), actual_weight, color='green', label='Actual weight', marker='*')
    plt.scatter(days, data, label='Measured weight', color='black', marker='o')
    plt.plot(days, predictions, label='Prediction', color='red', linestyle='--', marker='x')
    plt.plot(days, results, label='Filtered', color='blue', marker='+')
    plt.xticks(np.arange(0, 21), ['Day {}'.format(i) for i in range(0, 21)])
    plt.xlabel('Days')
    plt.ylabel('Weight')
    plt.title('G-H Filter')
    plt.legend()
    plt.grid(True)
    plt.show()