def g_h_filter(data, x0, dx, g, h, dt):
    x_est = x0
    results = []
    predictions = []
    for z in data:
        # prediction step
        x_pred = x_est + (dx*dt)
        predictions.append(x_pred)
        dx = dx
        # update step
        residual = z - x_pred
        dx = dx + h * (residual) / dt
        x_est = x_pred + g * residual
        results.append(x_est)
    return results,predictions