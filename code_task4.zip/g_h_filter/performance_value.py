import numpy as np
from numpy.random import randn
import matplotlib.pyplot as plt

from g_h_filter import g_h_filter


def gen_data(x0, dx, count, noise_factor):
    return [x0 + dx * i + randn() * noise_factor for i in range(count)]


def main():
    # measurements = gen_data(0, 1, 30, 1)
    measurements = gen_data(0, 1, 30, 1)
    data, _ = g_h_filter(data=measurements, x0=0., dt=1., g=.2, h=0.02, dx=1)
    x_axis = np.linspace(0, 29, 30)
    plt.figure(figsize=(8, 6))
    plt.xticks(x_axis)
    plt.plot(x_axis, data,marker='o', color='black',label='noise factor =1')
    measurements = gen_data(0, 1, 30, 10)
    data, _ = g_h_filter(data=measurements, x0=0., dt=1., g=.2, h=0.02, dx=1)
    plt.plot(x_axis, data, marker='x', color='green',label='noise factor =10')
    plt.title("GH_filter with different noise factors")
    plt.legend()
    plt.grid()
    plt.show()


if __name__ == '__main__':
    main()
